Sphere()
Shrink()
Show()
Render()

