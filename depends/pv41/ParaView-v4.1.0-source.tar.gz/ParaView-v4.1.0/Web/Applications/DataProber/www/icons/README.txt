Icon Sources
--------------------

data-folder-icon.png http://www.iconarchive.com/show/database-icons-by-fasticon/data-folder-icon.html
Window-Performance-64.png http://www.iconspedia.com/icon/window-performance-icon-37588.html
View-64.png http://www.iconspedia.com/icon/view-icon-20078.html
chart-bar-stacked-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-office-chart-bar-stacked-icon.html
chart-bar-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-office-chart-bar-icon.html
chart-bar-percentage-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-office-chart-bar-percentage-icon.html
chart-line-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-office-chart-line-icon.html
chart-line-stacked-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-office-chart-line-stacked-icon.html
chart-line-percentage-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-office-chart-line-percentage-icon.html
chart-area-stacked-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-office-chart-area-stacked-icon.html
chart-area-percentage-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-office-chart-area-percentage-icon.html
chart-scatter-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-office-chart-scatter-icon.html
go-previous-view-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-go-previous-view-icon.html
go-next-view-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-go-next-view-icon.html
zoom-fit-icon.png http://www.iconarchive.com/show/snowish-icons-by-saki/Actions-zoom-fit-icon.html
system-monitor-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Apps-utilities-system-monitor-icon.html
key-icon.png http://www.iconarchive.com/show/basic-2-icons-by-pixelmixer/key-icon.html
format-stroke-color-icon.png http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-format-stroke-color-icon.html
